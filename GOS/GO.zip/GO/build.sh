#!/bin/sh
sh getpkg.sh
pyinstaller -F GO.py
