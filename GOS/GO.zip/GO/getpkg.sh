#!/bin/sh
pip install --upgrade pip
pip install keyboard
pip install --upgrade keyboard
pip install pyinstaller
pip install --upgrade pyinstaller
