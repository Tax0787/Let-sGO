#!/bin/sh

sh makeExecutable.sh $1
