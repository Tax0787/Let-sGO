#!/bin/sh

chmod 777 $1
