clr = 'clear'
